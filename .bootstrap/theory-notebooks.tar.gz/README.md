# HSE–Laplace Source-Supported Partial Unified Representation

This repository studies one bounded question:

> How should multiple acquisition operators represent the same local dynamical process when their modal supports only partially overlap?

The project does not claim a universal representation for unrelated time series. Its current scope is one physical system family, one declared window-local Laplace-modal dictionary, and multiple acquisition operators such as sampling rates, sensor responses, channel sets and missingness patterns.

## Core idea: roles first, models second

The structural modal space is split into four roles:

\[
\mathcal H
=
\mathcal H_c
\oplus
\mathcal H_{p,d}
\oplus
\mathcal H_{m,d}
\oplus
\mathcal H_0.
\]

```text
common observable             -> canonicalize only with an anchored map
observed private              -> preserve exactly
source-supported missing      -> infer only with an identifiability certificate
source-global null            -> unsupported; no data-driven recovery claim
```

The term **source-supported missing** is deliberate. Visibility in another source domain makes inference eligible, but does not identify the missing conditional. Pairing, a physical coupling model or another explicit anchor is still required.

The representation makes two scientific decisions before model selection:

```text
1. role gate
   common / observed-private / source-supported-missing / global-null

2. identifiability gate
   can the missing conditional be identified from the declared source evidence?
```

Model complexity is then selected experimentally, not treated as a third method module.

## Candidate stochastic representation

When the role and identifiability conditions hold,

\[
C^*=T_d(C),
\qquad
P'=P,
\qquad
M'\sim q_\theta(M\mid C^*,P,\mathcal O_d).
\]

The canonicalizer and posterior are chosen from predeclared complexity ladders:

\[
T_d
\in
\{
\text{identity},
\text{affine},
\text{small nonlinear map},
\text{OT},
\text{Flow}
\},
\]

\[
q_\theta
\in
\{
\text{point},
\text{Gaussian},
\text{mixture},
\text{Diffusion}
\}.
\]

Flow and Diffusion are not mandatory. Flow is retained only when simpler anchored canonicalizers leave paired nonlinear headroom. Diffusion is retained only when simpler conditional families leave a proper-score and calibration gap.

## Formal proof and executable witness

Every numbered theory file now has one matching Notebook:

```text
theory/NN_theory_name.md
<->
theory/notebooks/NN_theory_name.ipynb
```

The Markdown file carries the general proof. The Notebook checks a finite special case, counterexample or numerical implication. Passing a Notebook does not prove the theorem and does not constitute real PHM evidence.

A result enters the paper's theoretical contribution set only after:

```text
complete conditional proof
+
matching Notebook passes in CI
+
claim wording respects assumptions
+
result is method-specific rather than established background
```

See `theory/README.md` for the complete map and contribution status.

## Current status

```text
stage: theory proofs + executable witness gate
formal_claim_supported: false
numbered theory documents: 25
matching source notebooks: 25
known-pole factorial experiment: not started
learned posterior: not started
learned flow: not started
real PHM evidence: not started
```

## Start here

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
python -m pip install -e ".[notebooks]"
python examples/analytic_unified_representation.py
python -m unittest discover -s tests -v
python theory/run_notebooks.py
```

To retain executed copies without modifying source notebooks:

```bash
python theory/run_notebooks.py \
  --output-dir theory/outputs/executed \
  --summary theory/outputs/validation.json
```

`theory/outputs/` is ignored by Git.

## Repository map

| Path | Purpose |
|---|---|
| `src/hse_laplace/` | Minimal analytic implementation |
| `theory/README.md` | Proof-to-Notebook map and contribution gate |
| `theory/*.md` | One formal derivation or boundary analysis per file |
| `theory/notebooks/*.ipynb` | One output-free executable witness per formal file |
| `theory/run_notebooks.py` | One-to-one mapping check and clean execution |
| `paper/main.md` | Core paper argument and admitted theoretical contributions |
| `paper/experiments.md` | Falsification and model-necessity gates |
| `paper/related_work.md` | Exact novelty boundary |
| `experiments/` | Executable scientific experiments |
| `tests/` | Behavioral mathematical invariants |

## Next decisive experiment

The next research PR remains the known-pole oracle study:

```text
full / partial support overlap
×
private task-irrelevant / task-relevant
×
unimodal / multimodal source-supported missing conditional
```

Mandatory controls remain paired versus unpaired evidence, affine versus nonlinear shared distortion, and a source-global-null negative control.

## Non-claims

The repository does not yet claim:

- recovery of every source-supported missing coordinate;
- recovery of source-global-null coordinates;
- necessity of Diffusion or Flow;
- superiority of Laplace coordinates over a matched time-domain latent;
- improved real PHM diagnosis, forecasting or domain generalization.
