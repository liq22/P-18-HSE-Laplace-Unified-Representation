# HSE–Laplace Source-Supported Partial Unified Representation

## Working title

**Observability- and Identifiability-Gated Laplace Stochastic Representation for Cross-Acquisition Time Series**

## Scope

The paper studies multiple acquisition operators observing the same window-local dynamical process or one declared system family. The operators may differ in sampling rate, anti-alias response, sensor transfer function, channel set, timestamps and sample reliability.

The paper does not cover unrelated systems, incompatible state dimensions or arbitrary label ontologies.

## Problem

Different acquisition operators do not merely shift a common distribution. They expose partially overlapping physical modal support. A full domain-invariant point embedding can erase information that exists only in a higher-support view, while a generative model can fabricate confidence for coordinates unsupported by source evidence.

## Core representation

For domain \(d\),

\[
\mathcal H
=
\mathcal H_c
\oplus
\mathcal H_{p,d}
\oplus
\mathcal H_{m,d}
\oplus
\mathcal H_0.
\]

| Role | Meaning | Permitted operation |
|---|---|---|
| \(\mathcal H_c\) | observable in every declared source domain | anchored canonicalization |
| \(\mathcal H_{p,d}\) | observed now, but not common to every domain | identity preservation |
| \(\mathcal H_{m,d}\) | hidden now, supported by at least one other source | conditional inference only when identifiable |
| \(\mathcal H_0\) | unsupported by every source | no data-driven recovery |

The symbol \(\mathcal H_{m,d}\) means **source-supported missing**. It is not synonymous with statistically recoverable.

## Method gates

### Structural role

A fixed modal slot receives one of the four roles from source-only structural acquisition operators.

### Conditional identifiability

A source-supported missing slot receives a learned posterior only if a declared certificate \(\chi_{d,k}=1\) is available. Acceptable certificates include the same `latent_event_id` observed by complementary acquisitions, a known simulator state, an injective physical coupling model, or another explicitly justified semantic anchor. Unpaired source marginals alone do not qualify.

### Minimum sufficient model selection

Model complexity is an experiment protocol rather than a method contribution. The canonicalizer and posterior are escalated only when predeclared simpler alternatives leave measurable headroom:

```text
identity -> affine -> small nonlinear map -> OT -> Flow
point -> Gaussian -> finite mixture -> Diffusion
```

## Candidate factorization

When the role and identifiability conditions pass,

\[
C^*=T_d(C),
\qquad
P'=P,
\qquad
M'\sim q_\theta(M\mid C^*,P,\mathcal O_d,\chi_d).
\]

The source-global-null block is excluded. The dependency is triangular: canonical shared state first, private identity second, conditional missing posterior third.

## Theory-to-contribution admission rule

The paper does not treat every valid mathematical lemma as a contribution. A result enters the theoretical contribution list only when:

1. a dedicated Markdown file states assumptions, lemmas, theorem, detailed proof and failure boundary;
2. a matching output-free Notebook executes successfully in CI;
3. the Notebook checks the central finite implication or counterexample;
4. the result is specific to the proposed representation rather than established probability-flow, stability or optimal-transport background;
5. the manuscript wording stays inside the theorem's scope.

The Notebook is a computational witness, not a substitute for proof. A successful theory gate does not establish learned-model value or real-PHM performance.

## Admitted theoretical contribution candidates

The following results satisfy the proof-plus-witness gate and are eligible for the paper's contribution section under their stated assumptions:

### C1 — Four-role source-supported modal decomposition

Formal proof: `theory/01_observable_subspace_decomposition.md`  
Executable witness: `theory/notebooks/01_observable_subspace_decomposition.ipynb`

The decomposition separates common observable, observed-private, source-supported missing and source-global-null directions. It prevents current-domain absence from being confused with data-supported recoverability.

### C2 — Task-risk cost of complete invariance

Formal proof: `theory/05_global_invariance_risk_lower_bound.md`  
Executable witness: `theory/notebooks/05_global_invariance_risk_lower_bound.ipynb`

When private information contributes conditionally to the task, forcing a higher-support representation to equal a lower-support representation incurs a Bayes log-loss gap bounded below by the corresponding conditional mutual information.

### C3 — Source support is not missing-conditional identifiability

Formal proof: `theory/16_source_supported_missing_identifiability.md`  
Executable witness: `theory/notebooks/16_source_supported_missing_identifiability.ipynb`

Unpaired source marginals can be identical while the desired missing conditional is opposite. Paired events or another explicit physical/semantic identification mechanism are therefore required.

### C4 — Triangular partial stochastic representation and paired approximation control

Formal proofs: `theory/20_triangular_stochastic_transport.md`, `theory/09_unified_representation_risk_bound.md`  
Executable witnesses: `theory/notebooks/20_triangular_stochastic_transport.ipynb`, `theory/notebooks/09_unified_representation_risk_bound.ipynb`

The proposed representation is a measurable triangular kernel that canonicalizes the shared block, preserves the observed-private block and assigns a conditional law only to identified source-supported missing coordinates. Under a same-event coupling and Lipschitz loss, blockwise representation error controls downstream risk difference.

## Results that are not paper contributions despite passing their Notebook

The following remain background, supporting properties, boundaries or model-selection gates:

- Flow–Diffusion marginal equivalence;
- posterior sufficiency as a general decision-theoretic fact;
- stable Laplace modal decay;
- product-case private-identity OT;
- commuting generators in the decoupled null model;
- Diffusion, Flow and Laplace necessity screens.

They may appear in preliminaries, appendix or experimental design, but they must not inflate the contribution count.

## Introduction logic

1. A single local fault transient can be observed through acquisition operators with different modal support.
2. Complete alignment can delete task-relevant private information.
3. Current-domain absence must be separated into source-supported missing and source-global null.
4. Source support alone does not identify a missing conditional.
5. Population marginal alignment alone can reverse semantics.
6. The proposed representation uses role and identifiability constraints before assigning canonicalization, identity or a probability model.
7. The known-pole experiment determines whether Laplace, Flow and Diffusion have independent headroom before a learned joint architecture is built.

## Candidate novelty

> An acquisition-observability-conditioned, identifiability-gated representation that canonicalizes only common modal support, preserves observed-private evidence, models source-supported missing modes only under a declared coupling certificate, and excludes source-global-null modes from recovery claims.

## Strongest competing explanations

- metadata and a hard support mask are sufficient;
- the source-supported missing conditional is not identified;
- a Gaussian or mixture posterior matches Diffusion;
- paired affine calibration, a small nonlinear map or ordinary OT matches Flow;
- a matched direct time-domain latent matches Laplace coordinates;
- apparent private information is acquisition identity;
- canonical marginal alignment permutes task semantics.

## Evidence boundary

```text
proved:
conditional mathematical implications under explicit assumptions

executed:
25 finite constructive or numerical theory witnesses
analytic implementation tests

not executed:
known-pole factorial experiment
learned posterior
learned canonical Flow
real paired-rate PHM experiment

not supported:
universal representation
global-null recovery
necessity of Diffusion or Flow
real diagnosis improvement
```
